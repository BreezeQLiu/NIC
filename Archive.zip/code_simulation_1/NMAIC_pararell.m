function re=NMAIC_pararell(sz,vari,z,x0,e0)
rng(z);
warning off all;
x=x0(:,z); 
e=e0(:,z);
mu=1*(x.^2+x+1).^0.5+5./(1+x.^2)+4*(floor(x)/2-floor(floor(x)/2));
% alpha, beta and gamma need to changed manually for each simulation
% notice that (floor(x)/2-floor(floor(x)/2)) equals 0.5*P(x), where P(x) is
% defined in our paper
                                                                  
                                                                  
y=mu+((vari)^0.5)*e;

options=optimset('LargeScale','off','Display','off','MaxFunEvals',10000);

a=fminsearch('FMSEA',[1;1],options,x,y);   % least squares estimation of candidate models
b=fminsearch('FMSEB',[1;1;1;1],options,x,y);
c=fminsearch('FMSEC',[1;1;1],options,x,y);


y1=a(1)+a(2)*x;             
y2=b(1)+b(2)*sin(b(3)+b(4)*x);
y3=c(1)+c(2)*x.^c(3);

sigma1=(y-y1)'*(y-y1)/sz;     
sigma2=(y-y2)'*(y-y2)/sz;
sigma3=(y-y3)'*(y-y3)/sz;
msigma=min([sigma1,sigma2,sigma3]); %select the minimum estimation as the estimated variance


a2=zeros(2,2);
b2=zeros(4,4);
c2=zeros(3,3);

for i=1:sz  % calculation of the adjusting term
    a2=a2+[1;x(i)]*[1;x(i)]';
    b2=b2+[1;sin(b(3)+b(4)*x(i));b(2)*cos(b(3)+b(4)*x(i));b(2)*x(i)*cos(b(3)+b(4)*x(i))]*[1;sin(b(3)+b(4)*x(i));b(2)*cos(b(3)+b(4)*x(i));b(2)*x(i)*cos(b(3)+b(4)*x(i))]'-...
             (y(i)-b(1)-b(2)*sin(b(3)+b(4)*x(i)))*...
              [0,0,0,0;...
              0,0,cos(b(3)+b(4)*x(i)),x(i)*cos(b(3)+b(4)*x(i));...
              0,cos(b(3)+b(4)*x(i)),-b(2)*sin(b(3)+b(4)*x(i)),-b(2)*x(i)*sin(b(3)+b(4)*x(i));...
              0,x(i)*cos(b(3)+b(4)*x(i)),-b(2)*x(i)*sin(b(3)+b(4)*x(i)),-b(2)*x(i)*x(i)*sin(b(3)+b(4)*x(i))];
    c2=c2+[1;x(i)^c(3);c(2)*log(x(i))*x(i)^c(3)]*[1;x(i)^c(3);c(2)*log(x(i))*x(i)^c(3)]'-(y(i)-c(1)-c(2)*x(i)^c(3))*[0,0,0;0,0,log(x(i))*x(i)^c(3);0,log(x(i))*x(i)^c(3),c(2)*log(x(i))*log(x(i))*(x(i)^c(3))];
end

adjust1=0;
adjust2=0;
adjust3=0;

for i=1:sz
    adjust1=adjust1+2*msigma*[1;x(i)]'*((a2)^(-1))*[1;x(i)];
    adjust2=adjust2+2*msigma*[1;sin(b(3)+b(4)*x(i));b(2)*cos(b(3)+b(4)*x(i));b(2)*x(i)*cos(b(3)+b(4)*x(i))]'*((b2)^(-1))*[1;sin(b(3)+b(4)*x(i));b(2)*cos(b(3)+b(4)*x(i));b(2)*x(i)*cos(b(3)+b(4)*x(i))];
    adjust3=adjust3+2*msigma*[1;x(i)^c(3);c(2)*log(x(i))*x(i)^c(3)]'*((c2)^(-1))*[1;x(i)^c(3);c(2)*log(x(i))*x(i)^c(3)];
end

NIC=[sz*sigma1+adjust1;sz*sigma2+adjust2;sz*sigma3+adjust3];

aic1=sz*log(sigma1)+4; %calculation of AIC for each model
aic2=sz*log(sigma2)+8;
aic3=sz*log(sigma3)+6;

bic1=sz*log(sigma1)+log(sz)*2; %calculation of BIC for each model 
bic2=sz*log(sigma2)+log(sz)*4;
bic3=sz*log(sigma3)+log(sz)*3;

aic=[aic1;aic2;aic3]; 
bic=[bic1;bic2;bic3];

aicw=exp(-0.5*(aic-aic(1)))/sum(exp(-0.5*(aic-aic(1)))); %weight of SAIC and SBIC
bicw=exp(-0.5*(bic-bic(1)))/sum(exp(-0.5*(bic-bic(1))));

cp1=sigma1*sz+sigma1*4;  %calculation of Mallows Cp for each model
cp2=sigma2*sz+sigma2*8;
cp3=sigma3*sz+sigma3*6;
cp=[cp1;cp2;cp3];         

FW=@(w)FMSEW(w,y,y1,y2,y3,adjust1,adjust2,adjust3);

w=fminsearch(FW,ones(3,1),options);
w=exp(w)/sum(exp(w)); % minimizing exp(w)/sum(exp(w)) instead of w avoids the situation where w(i)<0 for some i

risknlma=(mu-w(1)*y1-w(2)*y2-w(3)*y3)'*(mu-w(1)*y1-w(2)*y2-w(3)*y3); %calculation of loss function, which then will be averaged as the risk
risk1=(mu-y1)'*(mu-y1);
risk2=(mu-y2)'*(mu-y2);
risk3=(mu-y3)'*(mu-y3);
risk=[risk1;risk2;risk3];
riskaic=risk(aic==min(aic));
riskbic=risk(bic==min(bic));
risknlc=risk(NIC==min(NIC));
risksaic=(mu-aicw(1)*y1-aicw(2)*y2-aicw(3)*y3)'*(mu-aicw(1)*y1-aicw(2)*y2-aicw(3)*y3);
risksbic=(mu-bicw(1)*y1-bicw(2)*y2-bicw(3)*y3)'*(mu-bicw(1)*y1-bicw(2)*y2-bicw(3)*y3);
riskcp=risk(cp==min(cp));
re=[riskaic,riskbic,riskcp,risksaic,risksbic,risknlc,risknlma];
end

