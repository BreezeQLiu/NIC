function MSEB=FMSEB(b,x,y)

MSEB=(y-b(1)-b(2)*sin(b(3)+b(4)*x))'*(y-b(1)-b(2)*sin(b(3)+b(4)*x));

end