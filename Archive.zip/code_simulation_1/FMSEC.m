function MSEC=FMSEC(c,x,y)

MSEC=(y-c(1)-c(2)*x.^c(3))'*(y-c(1)-c(2)*x.^c(3));

end