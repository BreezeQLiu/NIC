function MSEW=FMSEW(w,y,y1,y2,y3,adjust1,adjust2,adjust3)
w=exp(w)/sum(exp(w));
MSEW=(y-w(1)*y1-w(2)*y2-w(3)*y3)'*(y-w(1)*y1-w(2)*y2-w(3)*y3)+w(1)*adjust1+w(2)*adjust2+w(3)*adjust3;
end
    