tic
clear all
close all
warning off all
k=1000; %number of replications
samplesize=[50 200 500 1000];
A=5.9110;   %A is the variance of mu, which needs to changed manually;
for s=1:4
    sz=samplesize(s);
    for l=1:9
        r=0.1*l;    %R-square, from 0.1 to 0.9
        vari=A/r-A; % R-square equals A/(vari+A),so vari equals A/R^2-A
        l 
        re=zeros(k,7);
        rng(0);
        x0=10*rand(sz,k);  % generate the input x
        e0=randn(sz,k);    % generate the error term
        parfor z=1:k
            re(z,:)=NMAIC_pararell(sz,vari,z,x0,e0);
        end

        H01=sum(re(:,1))/k;
        H02=sum(re(:,2))/k;
        H03=sum(re(:,3))/k;
        H04=sum(re(:,4))/k;
        H05=sum(re(:,5))/k;
        H06=sum(re(:,6))/k;
        H07=sum(re(:,7))/k;
        H(l,1:7)=([H01,H02,H03,H04,H05,H06,H07])/H07;
    end
    
    fname=[num2str(A) '_' num2str(s) '.csv'];
    save(fname, 'H', '-ascii', '-double', '-tabs');
    x=(0.1:0.1:0.9)';
    H1=H(:,1);
    H2=H(:,2);
    H3=H(:,3);
    H4=H(:,4);
    H5=H(:,5);
    H6=H(:,6);
    H7=H(:,7);
    subplot(2,2,s);
    plot(x,H1,'-s',x,H2,'-o',x,H3,'-^',x,H4,'-p',x,H5,'-*',x,H6,'-x',x,H7,'-k');
    xlabel('R-Square');
    ylabel('Relative Risk');
    title(['n = ',mat2str(sz)]);
    if sz==50
       legend('AIC','BIC','Mallows Cp','SAIC','SBIC','NIC','NMA');
    end  
end
toc
        