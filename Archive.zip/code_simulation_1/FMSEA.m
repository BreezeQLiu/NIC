function MSEA=FMSEA(a,x,y)

MSEA=(y-a(1)-a(2)*x)'*(y-a(1)-a(2)*x);

end