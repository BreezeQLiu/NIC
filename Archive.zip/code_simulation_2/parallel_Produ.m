function re=parallel_Produ(sz,vari,x01,x02,e0,thre,z)
warning('off','all');
options=optimset('LargeScale','off','Display','off','MaxFunevals',10000);
e=e0(:,z);
x1=x01(:,z);
x2=x02(:,z);
mu=zeros(sz,1);

for k=1:sz
    if x1(k)+x2(k)<thre(1)
        mu(k,1)=0.6*exp(0.3*log(x1(k))+log(x2(k))+0.05*log(x1(k))^2+0.05*log(x2(k))^2);
    elseif x1(k)+x2(k)<thre(2)
        mu(k,1)=0.8*(0.4*x1(k)^0.5+0.6*x2(k)^0.5)^2;
    else
        mu(k,1)=x1(k)^0.3*x2(k)^0.8;
    end
end
%calculation of mu.

y=mu+(vari)^0.5*e;

f1=@(a)CD(a,x1,x2,y);
f2=@(b)CES(b,x1,x2,y);
f3=@(c)TRANSLOG(c,x1,x2,y);

a=fminsearch(f1,ones(3,1),options);
b=fminsearch(f2,ones(6,1),options); 
b(2)=exp(b(2)); %transformation that guarantees that b(2) is strictly positive    
b(4)=exp(b(4)); %transformation that guarantees that b(4) is strictly positive    
c=fminsearch(f3,ones(6,1),options);

y1=a(1)*(x1.^a(2)).*(x2.^a(3));
y2=b(1)*(b(2)*x1.^b(3)+b(4)*x2.^b(5)).^b(6);
y3=c(1)*exp(c(2)*log(x1)+c(3)*log(x2)+c(4)*log(x1).^2+c(5)*log(x1).*log(x2)+c(6)*log(x2).^2);

LOSS=[(mu-y1)'*(mu-y1);(mu-y2)'*(mu-y2);(mu-y3)'*(mu-y3)];

sigma1=(y-y1)'*(y-y1)/sz;
sigma2=(y-y2)'*(y-y2)/sz;
sigma3=(y-y3)'*(y-y3)/sz;
msig=min([sigma1, sigma2, sigma3]);
AIC=[sz*log(sigma1)+6; sz*log(sigma2)+12; sz*log(sigma3)+12];
BIC=[sz*log(sigma1)+log(sz)*3; sz*log(sigma2)+log(sz)*6; sz*log(sigma3)+log(sz)*6];
CP=[sigma1*(sz+6); sigma2*(sz+12);sigma3*(sz+12)];
AICW=exp(-0.5*(AIC-AIC(1)))/sum(exp(-0.5*(AIC-AIC(1))));
BICW=exp(-0.5*(BIC-BIC(1)))/sum(exp(-0.5*(BIC-BIC(1))));

lambda1=0;
lambda2=0;
lambda3=0;

a1=a(1);a2=a(2);a3=a(3);
b1=b(1);b2=b(2);b3=b(3); b4=b(4);b5=b(5);b6=b(6);    
c1=c(1);c2=c(2);c3=c(3);c4=c(4);c5=c(5);c6=c(6);

for i=1:sz
    q1=x1(i);q2=x2(i);
    [dh1, ddh1, dh2, ddh2, dh3, ddh3]=gh( q1, q2, a1, a2, a3, b1, b2, b3, b4, b5, b6, c1, c2, c3, c4, c5, c6);     %%%%%%changed
    lambda1=lambda1+(dh1)'*(dh1)-(y(i)-y1(i))*(ddh1);
    lambda2=lambda2+(dh2)'*(dh2)-(y(i)-y2(i))*(ddh2);
    lambda3=lambda3+(dh3)'*(dh3)-(y(i)-y3(i))*(ddh3);
end

adjust1=0;
adjust2=0;
adjust3=0;

for i=1:sz
    q1=x1(i);q2=x2(i);
    [dh1, ~, dh2, ~, dh3, ~]=gh( q1, q2, a1, a2, a3, b1, b2, b3, b4, b5, b6, c1, c2, c3, c4, c5, c6);       %%%%%%%changed
    adjust1=adjust1+2*msig*(dh1)*(lambda1)^(-1)*(dh1)';
    adjust2=adjust2+2*msig*(dh2)*(lambda2)^(-1)*(dh2)';
    adjust3=adjust3+2*msig*(dh3)*(lambda3)^(-1)*(dh3)';
end

NLC=[sz*sigma1+adjust1; sz*sigma2+adjust2; sz*sigma3+adjust3];

fw=@(w)NLCW(w,y,y1,y2,y3,adjust1,adjust2,adjust3);


w=fminsearch(fw,ones(3,1)/3,options);   
w=exp(w)/sum(exp(w));


NLMALOSS=(mu-y1*w(1)-y2*w(2)-y3*w(3))'*(mu-y1*w(1)-y2*w(2)-y3*w(3));

AICLOSS=LOSS((AIC==min(AIC)));
BICLOSS=LOSS((BIC==min(BIC)));
CPLOSS=LOSS((CP==min(CP)));
SAICLOSS=(mu-y1*AICW(1)-y2*AICW(2)-y3*AICW(3))'*(mu-y1*AICW(1)-y2*AICW(2)-y3*AICW(3));
SBICLOSS=(mu-y1*BICW(1)-y2*BICW(2)-y3*BICW(3))'*(mu-y1*BICW(1)-y2*BICW(2)-y3*BICW(3));
NLCLOSS=LOSS((NLC==min(NLC)));

re=[AICLOSS BICLOSS CPLOSS SAICLOSS SBICLOSS NLCLOSS NLMALOSS];


end