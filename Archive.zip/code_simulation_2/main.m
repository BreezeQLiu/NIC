clear all 
close all
tic
A0=[0.1050; 0.0522; 0.0798; 0.1813]; 
%A0 is a variance vector whose i-th element corresponds to the
%variance of mu (conditional mean) in the i-th data genrating process. 
threshold=[2.25 2.5; 2.25 3.75; 3.5 3.75; 2+(2/3)^0.5 4-(2/3)^0.5];
%theshold is a matrix whose i-th row corresponds to the therehold used in
%the i-th data generating process.
for i0=1:4
    thre=threshold(i0,:);
    A=A0(i0,:);
    k=1000; %number of replications.
    symf;   %generate gh.m, file for computation of the Gradiant and Hessian.
    samplesize=[50 200 500 1000];
    for s=1:4
        
        for l=1:9
            re=zeros(k,7);
            l
            NLCLOSS=0;
            NLMALOSS=0;
            AICLOSS=0;
            BICLOSS=0;
            CPLOSS=0;
            SAICLOSS=0;
            SBICLOSS=0;
            o=0;
            vari=A/(0.1*l)-A;
            sz=samplesize(s);
            rng(0);
            x01=rand(sz,k)+1;  % x01 and x02 refer to two inputs.
            x02=rand(sz,k)+1;
            e0=randn(sz,k);
            re0=zeros(1,7);
            parfor z=1:k
                re(z,:)=parallel_Produ(sz,vari,x01,x02,e0,thre,z);
            end
            H01=sum(re(:,1))/k;
            H02=sum(re(:,2))/k;
            H03=sum(re(:,3))/k;
            H04=sum(re(:,4))/k;
            H05=sum(re(:,5))/k;
            H06=sum(re(:,6))/k;
            H07=sum(re(:,7))/k;
            
            H(l,1:7)=([H01,H02,H03,H04,H05,H06,H07])/H07;
            
        end
        fname=[num2str(i0) '_' num2str(s) '.csv'];
        save(fname, 'H', '-ascii', '-double', '-tabs');
        x=0.1:0.1:0.9;
        H1=H(:,1);
        H2=H(:,2);
        H3=H(:,3);
        H4=H(:,4);
        H5=H(:,5);
        H6=H(:,6);
        H7=H(:,7);
        subplot(2,2,s);
        plot(x,H1,'-s',x,H2,'-o',x,H3,'-^',x,H4,'-p',x,H5,'-*',x,H6,'-x',x,H7,'-k');
        xlabel('R-Square');
        ylabel('Relative Risk');
        xlim([0.1 0.9]);
        title(['n = ',mat2str(sz)]);
        if sz==50
            legend('AIC','BIC','Cp','SAIC','SBIC','NLC','NLMA');
        end  
        
            poolobj = gcp('nocreate');
            delete(poolobj);
    end
    [ax4,h3]=suplabel(['Thre=', mat2str(round(thre,2))], 't');
    fn=num2str(i0);
    fname1=[fn '.eps'];
    fname2=[fn '.fig'];
    saveas(gcf,fname1, 'psc2');
    saveas(gcf,fname2);
    if i0<4
        figure;
    end
end
toc