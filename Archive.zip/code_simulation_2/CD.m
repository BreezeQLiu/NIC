function mo=CD(a,x1,x2,y)
mo=(y-a(1)*(x1.^a(2)).*(x2.^a(3)))'*(y-a(1)*(x1.^a(2)).*(x2.^a(3)));
end