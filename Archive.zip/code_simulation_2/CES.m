function mo=CES(b,x1,x2,y)
mo=(y-b(1)*(exp(b(2))*x1.^b(3)+exp(b(4))*x2.^b(5))).^b(6)'*(y-b(1)*(exp(b(2))*x1.^b(3)+exp(b(4))*x2.^b(5))).^b(6);
end