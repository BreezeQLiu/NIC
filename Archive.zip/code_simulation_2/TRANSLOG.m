function mo=TRANSLOG(c,x1,x2,y)
mo=(y-c(1)*exp(c(2)*log(x1)+c(3)*log(x2)+c(4)*log(x1).^2+c(5)*log(x1).*log(x2)+c(6)*log(x2).^2))'*(y-c(1)*exp(c(2)*log(x1)+c(3)*log(x2)+c(4)*log(x1).^2+c(5)*log(x1).*log(x2)+c(6)*log(x2).^2));
end