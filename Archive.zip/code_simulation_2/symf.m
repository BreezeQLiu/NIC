%generate gh.m, file for function of Gradian and Hessian.
%Author Qingfeng Liu
function l=symf
syms q1 q2 a1 a2 a3 b1 b2 b3 b4 b5 b6 c1 c2 c3 c4 c5 c6
h1=a1*(q1^a2)*(q2^a3);         %Cobb-Douglas Production Function
h2=b1*(b2*q1^b3+b4*q2^b5)^b6;  %CES production function
h3=c1*exp(c2*log(q1)+c3*log(q2)+c4*log(q1)^2+c5*log(q1)*log(q2)+c6*log(q2)^2);  %Translog Production Function
dh1=jacobian(h1,[a1 a2 a3]);   %d refers to gradient
ddh1=jacobian(dh1,[a1 a2 a3]);  %%dd refers to Hessian 
dh2=jacobian(h2,[b1 b2 b3 b4 b5 b6]);
ddh2=jacobian(dh2,[b1 b2 b3 b4 b5 b6]);
dh3=jacobian(h3,[c1 c2 c3 c4 c5 c6]);
ddh3=jacobian(dh3,[c1 c2 c3 c4 c5 c6]);
dh1=char(dh1);
dh1(1:6)=[];
ddh1=char(ddh1);
ddh1(1:6)=[];

dh2=char(dh2);
dh2(1:6)=[];
ddh2=char(ddh2);
ddh2(1:6)=[];
dh3=char(dh3);
dh3(1:6)=[];
ddh3=char(ddh3);
ddh3(1:6)=[];
fileID = fopen('gh.m','w');
fprintf(fileID,'%1s \n', 'function [dh1, ddh1, dh2, ddh2, dh3, ddh3]=gh( q1, q2, a1, a2, a3, b1, b2, b3, b4, b5, b6, c1, c2, c3, c4, c5, c6)');
fprintf(fileID,'%1s \n', ['dh1=' dh1 ';']);
fprintf(fileID,'%1s \n', ['ddh1=' ddh1 ';']);
fprintf(fileID,'%1s \n', ['dh2=' dh2 ';']);
fprintf(fileID,'%1s \n', ['ddh2=' ddh2 ';']);
fprintf(fileID,'%1s \n', ['dh3=' dh3 ';']);
fprintf(fileID,'%1s \n', ['ddh3=' ddh3 ';']);
fprintf(fileID,'%1s \n', 'ddh1=reshape(ddh1,3,3);');
fprintf(fileID,'%1s \n', 'ddh2=reshape(ddh2,6,6);');
fprintf(fileID,'%1s \n', 'ddh3=reshape(ddh3,6,6);');
fclose(fileID);
l=0;